const VERSION = 'V4';

function log(msg) {
    console.log(VERSION,msg);
}
function getCacheName() {
    return 'app-cache-' + VERSION;
}
log('Installing service worker');

self.addEventListener('install',event=> event.waitUntil(installServiceWorker()));

async function installServiceWorker() {
    log('Service worker installation started');
    const cache = await caches.open(getCacheName());
    return cache.addAll([
        '/',
        'polyfills.bundle.js',
        'inline.bundle.js',
        'styles.bundle.js',
        'vendor.bundle.js',
        'main.bundle.js'
    ]);
}
self.addEventListener('fetch', event=> event.respondWith(cacheThenNetwork(event)));

async function cacheThenNetwork(event) {
    const cache = await caches.open(getCacheName());
    const cachedResponse = await cache.match(event.request);
    if(cachedResponse) {
        log('Serving from cache : ' + event.request.url);
        return cachedResponse;
    }
    const networkResponse = await fetch(event.request);
    log('Calling network : ', event.request.url);
    return networkResponse;
}


self.addEventListener('activate',event=> activateServiceWorkers());

async function activateServiceWorkers(event) {
    log('Version is activated');
    const cacheKeys = await caches.keys();
    const currentCacheKey = getCacheName();
    cacheKeys.forEach(cacheKey=> {
        if(cacheKeys!== currentCacheKey) {
            caches.delete(cacheKey);
        }
    });
}