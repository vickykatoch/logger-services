import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { CompositeLadderComponent } from './components/composite-ladder/composite-ladder.component';
import { LadderViewComponent } from './components/ladder-view/ladder-view.component';
import { LadderRowComponent } from './components/ladder-row/ladder-row.component';
import { LadderColComponent } from './components/ladder-columns/ladder-col.component';
import { LadderInputComponent } from './components/ladder-input/ladder-input.component';
import { LadderOhlcComponent } from './components/ladder-ohlc/ladder-ohlc.component';
import { LadderActionsComponent } from './components/ladder-actions/ladder-actions.component';
import { LadderInstrumentInfoComponent } from './components/ladder-instrument-info/ladder-instrument-info.component';


@NgModule({
  declarations: [
    AppComponent,
    CompositeLadderComponent,
    LadderViewComponent,
    LadderRowComponent,
    LadderColComponent,
    LadderInputComponent,
    LadderOhlcComponent,
    LadderActionsComponent,
    LadderInstrumentInfoComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
