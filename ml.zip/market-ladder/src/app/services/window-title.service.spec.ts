import { TestBed, inject } from '@angular/core/testing';

import { WindowTitleService } from './window-title.service';

describe('WindowTitleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WindowTitleService]
    });
  });

  it('should be created', inject([WindowTitleService], (service: WindowTitleService) => {
    expect(service).toBeTruthy();
  }));
});
