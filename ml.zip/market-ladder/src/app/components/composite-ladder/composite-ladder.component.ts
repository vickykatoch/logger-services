import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'falcon-composite-ladder',
  templateUrl: './composite-ladder.component.html',
  styleUrls: ['./composite-ladder.component.scss']
})
export class CompositeLadderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
