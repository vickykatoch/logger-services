import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompositeLadderComponent } from './composite-ladder.component';

describe('CompositeLadderComponent', () => {
  let component: CompositeLadderComponent;
  let fixture: ComponentFixture<CompositeLadderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompositeLadderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompositeLadderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
