import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'falcon-ladder-actions',
  templateUrl: './ladder-actions.component.html',
  styleUrls: ['./ladder-actions.component.scss']
})
export class LadderActionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
