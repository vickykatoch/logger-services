import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LadderActionsComponent } from './ladder-actions.component';

describe('LadderActionsComponent', () => {
  let component: LadderActionsComponent;
  let fixture: ComponentFixture<LadderActionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LadderActionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LadderActionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
