import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LadderViewComponent } from './ladder-view.component';

describe('LadderViewComponent', () => {
  let component: LadderViewComponent;
  let fixture: ComponentFixture<LadderViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LadderViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LadderViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
