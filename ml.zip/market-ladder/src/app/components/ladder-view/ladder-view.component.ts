import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'falcon-ladder-view',
  templateUrl: './ladder-view.component.html',
  styleUrls: ['./ladder-view.component.scss']
})
export class LadderViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
