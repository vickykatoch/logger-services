import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'falcon-ladder-ohlc',
  templateUrl: './ladder-ohlc.component.html',
  styleUrls: ['./ladder-ohlc.component.scss']
})
export class LadderOhlcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
