import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LadderRowComponent } from './ladder-row.component';

describe('LadderRowComponent', () => {
  let component: LadderRowComponent;
  let fixture: ComponentFixture<LadderRowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LadderRowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LadderRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
