import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'falcon-ladder-row',
  templateUrl: './ladder-row.component.html',
  styleUrls: ['./ladder-row.component.scss']
})
export class LadderRowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
