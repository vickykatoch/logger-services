import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LadderInstrumentInfoComponent } from './ladder-instrument-info.component';

describe('LadderInstrumentInfoComponent', () => {
  let component: LadderInstrumentInfoComponent;
  let fixture: ComponentFixture<LadderInstrumentInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LadderInstrumentInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LadderInstrumentInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
