import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'falcon-ladder-instrument-info',
  templateUrl: './ladder-instrument-info.component.html',
  styleUrls: ['./ladder-instrument-info.component.scss']
})
export class LadderInstrumentInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
