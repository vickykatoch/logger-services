import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'falcon-ladder-input',
  templateUrl: './ladder-input.component.html',
  styleUrls: ['./ladder-input.component.scss']
})
export class LadderInputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
