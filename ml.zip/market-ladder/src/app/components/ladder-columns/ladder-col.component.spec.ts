import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LadderColComponent } from './ladder-col.component';

describe('LadderColComponent', () => {
  let component: LadderColComponent;
  let fixture: ComponentFixture<LadderColComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LadderColComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LadderColComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
