import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'falcon-ladder-col',
  templateUrl: './ladder-col.component.html',
  styleUrls: ['./ladder-col.component.scss']
})
export class LadderColComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
