export interface LadderColumn<T> {
    name: string;
    visible: boolean;
    data: T
}

export class LadderColumnObjectBuilder {
    private static _instance = new LadderColumnObjectBuilder();

    constructor() {
        if (LadderColumnObjectBuilder._instance) {
            throw new Error("Error: Instantiation failed: Use LoggingStore.instance instead of new.");
        }
        LadderColumnObjectBuilder._instance = this;
    }
    static get instance(): LadderColumnObjectBuilder {
        return LadderColumnObjectBuilder._instance;
    }

    build<T>(name: string, show: boolean, data: T): LadderColumn<T> {
        return {
            name,
            visible: show,
            data
        };
    }
}
